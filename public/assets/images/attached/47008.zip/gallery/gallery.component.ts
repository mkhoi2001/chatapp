import { Component, OnInit } from '@angular/core';
import { Lightbox } from 'ngx-lightbox';

import { TopbarService } from '../../core/services/topbar.service';
import { titlebar } from '../../layouts/topbar/titlebar.model';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.scss']
})

/**
 * Gallery component
 */
export class GalleryComponent implements OnInit {

  albums = [];
  require: any;

  private titleObj = new titlebar();

  constructor(private topBarService: TopbarService, private lightbox: Lightbox) {
    this.titleObj.title = 'Gallery';
    this.titleObj.subItem1 = 'Extras';
    this.topBarService.activeMenuChange.next(this.titleObj);
    for (let i = 1; i <= 6; i++) {
      const src = '../../../assets/images/small/img-' + i + '.jpg';
      const caption = 'Image ' + i + ' caption here';
      const thumb = '../../../assets/images/small/img-' + i + '.jpg';
      const album = {
        src,
        caption,
        thumb
      };
      this.albums.push(album);
    }
  }

  ngOnInit(): void {
  }

  /**
   * Open lightbox
   */
  open(index: number): void {
    // open lightbox
    this.lightbox.open(this.albums, index);
  }

  /**
   * Close lightbox
   */
  close(): void {
    // close lightbox programmatically
    this.lightbox.close();
  }
}
